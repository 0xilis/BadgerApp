//
//  BadgerAppSelectionViewController.m
//  BadgerApp
//
//  Created by Snoolie Keffaber on 9/6/22.
//

#import "ViewController.h"
#import "BadgerAppSelectionViewController.h"
#import "BadgeCountMinimumViewController.h"

NSMutableArray *appImages;
NSMutableArray *appNames;
NSMutableArray *appBundleIDs;

@interface UIImage (UIApplicationIconPrivate)
+ (instancetype)_applicationIconImageForBundleIdentifier:(NSString*)bundleIdentifier format:(int)format scale:(CGFloat)scale;
@end

@interface LSApplicationState : NSObject
-(bool)isValid;
@end

@interface LSApplicationRecord : NSObject
@property (nonatomic,readonly) NSArray* appTags; // 'hidden'
@property (getter=isLaunchProhibited,readonly) BOOL launchProhibited;
@end

@interface LSApplicationProxy : NSObject
+ (LSApplicationProxy *)applicationProxyForIdentifier:(id)appIdentifier;
@property(readonly) NSString * applicationIdentifier;
@property(readonly) NSString * bundleVersion;
@property(readonly) NSString * bundleExecutable;
@property(readonly) NSArray * deviceFamily;
@property(readonly) NSURL * bundleContainerURL;
@property(readonly) NSString * bundleIdentifier;
@property(readonly) NSURL * bundleURL;
@property(readonly) NSURL * containerURL;
@property(readonly) NSURL * dataContainerURL;
@property(readonly) NSString * localizedShortName;
@property(readonly) NSString * localizedName;
@property(readonly) NSString * shortVersionString;
@property (readonly) BOOL isStickerProvider;
@property(nonatomic, readonly) NSArray *appTags; //thx KBAppList
@property(readonly, nonatomic) NSString *applicationType;
@property(nonatomic, readonly) NSDictionary *iconsDictionary;
@property (getter=isLaunchProhibited,nonatomic,readonly) BOOL launchProhibited;
- (NSArray *)_boundIconFileNames; // iOS 11+
- (NSArray *)boundIconFileNames;  // iOS 10-
- (void)addObserver:(id)arg1;
-(LSApplicationState*)appState;
- (LSApplicationRecord*)correspondingApplicationRecord;
@end

@interface LSApplicationWorkspace : NSObject
+ (id) defaultWorkspace;
- (BOOL) registerApplication:(id)application;
- (BOOL) unregisterApplication:(id)application;
- (BOOL) invalidateIconCache:(id)bundle;
- (BOOL) registerApplicationDictionary:(id)application;
- (BOOL) installApplication:(id)application withOptions:(id)options;
- (BOOL) _LSPrivateRebuildApplicationDatabasesForSystemApps:(BOOL)system internal:(BOOL)internal user:(BOOL)user;
-(NSArray <LSApplicationProxy*> *)allApplications;
@end

@interface BadgerAppSelectionViewController () <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;
@end

@implementation BadgerAppSelectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Apps";
    
    NSLog(@"lez attempt dis");
    appImages = [[NSMutableArray alloc]init];
    appNames = [[NSMutableArray alloc]init];
    appBundleIDs = [[NSMutableArray alloc]init];
    //Class LSApplicationWorkspace = NSClassFromString(@"LSApplicationWorkspace");
    Class LSApplicationWorkspace = NSClassFromString(@"LSApplicationWorkspace");
    id AAURLConfiguration1 = [LSApplicationWorkspace defaultWorkspace];
    [AAURLConfiguration1 addObserver:self];
    if (AAURLConfiguration1) {
        id arrApp = [AAURLConfiguration1 allApplications];
        for (int i=0; i<[arrApp count]; i++) {
            LSApplicationProxy *app = [arrApp objectAtIndex:i];
            NSArray* appTags;
            BOOL launchProhibited = NO;
            if([app respondsToSelector:@selector(correspondingApplicationRecord)])
                {
                    // On iOS 14, self.appTags is always empty but the application record still has the correct ones
                    LSApplicationRecord* record = [app correspondingApplicationRecord];
                    appTags = record.appTags;
                    launchProhibited = record.launchProhibited;
                } else {
                    appTags = app.appTags;
                    launchProhibited = app.launchProhibited;
                }
            if ((![appTags containsObject:@"hidden"]) && (!launchProhibited) && ![[app applicationIdentifier] isEqualToString:@"com.apple.webapp"]) {
                
                //NSLog(@"appTags: %@",app.appTags);
                //NSString* bundleId =[app applicationIdentifier];
                //NSLog(@"app: %@",bundleId);
                //NSLog(@"apploc: %s",[[app bundleURL] fileSystemRepresentation]);
                //NSLog(@"app name: %@",[app localizedName]);
                //get CFBundleIcons (or CFBundleIcons~ipad) from info.plist in [[app bundleURL] fileSystemRepresentation]. CFBundleIconName has CFBundlePrimaryIcon which has CFBundleIconFiles, though it may also have CFBundleIconName
                NSMutableDictionary *infoPlist = [[NSMutableDictionary alloc] initWithContentsOfFile:[NSString stringWithFormat:@"%s/Info.plist",[[app bundleURL] fileSystemRepresentation]]];
                UIImage *appIcon = [UIImage _applicationIconImageForBundleIdentifier:[app applicationIdentifier] format:1 scale:[UIScreen mainScreen].scale];
                if (appIcon) {
                    [appImages addObject:appIcon];
                } else {
                    [appImages addObject:@"NOIMG"];
                }
                [appNames addObject:[app localizedName]];
                [appBundleIDs addObject:[app applicationIdentifier]];
                //[infoPlist setObject:@"788" forKey:@"CFBundleVersion"];
                //[infoPlist writeToFile:[NSString stringWithFormat:@"%s/Info.plist",[[app bundleURL] fileSystemRepresentation]] atomically:YES];
                /*if ([infoPlist objectForKey:@"CFBundleIcons"]) {
                    if ([[infoPlist objectForKey:@"CFBundleIcons"] objectForKey:@"CFBundlePrimaryIcon"]) {
                        if ([[[infoPlist objectForKey:@"CFBundleIcons"] objectForKey:@"CFBundlePrimaryIcon"] objectForKey:@"CFBundleIconFiles"]) {
                                if ([[[[infoPlist objectForKey:@"CFBundleIcons"] objectForKey:@"CFBundlePrimaryIcon"] objectForKey:@"CFBundleIconFiles"]objectAtIndex:0]) {
                                    
                                    
                                        if ([UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%s/%@.png",[[app bundleURL] fileSystemRepresentation],[[[[infoPlist objectForKey:@"CFBundleIcons"] objectForKey:@"CFBundlePrimaryIcon"] objectForKey:@"CFBundleIconFiles"]objectAtIndex:0]]]) {
                                    [appImages addObject:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%s/%@.png",[[app bundleURL] fileSystemRepresentation],[[[[infoPlist objectForKey:@"CFBundleIcons"] objectForKey:@"CFBundlePrimaryIcon"] objectForKey:@"CFBundleIconFiles"]objectAtIndex:0]]]];
                                            [appNames addObject:[app localizedName]];
                                            [appBundleIDs addObject:[app applicationIdentifier]];
                                        } else if ([UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%s/%@@2x.png",[[app bundleURL] fileSystemRepresentation],[[[[infoPlist objectForKey:@"CFBundleIcons"] objectForKey:@"CFBundlePrimaryIcon"] objectForKey:@"CFBundleIconFiles"]objectAtIndex:0]]]) {
                                [appImages addObject:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%s/%@@2x.png",[[app bundleURL] fileSystemRepresentation],[[[[infoPlist objectForKey:@"CFBundleIcons"] objectForKey:@"CFBundlePrimaryIcon"] objectForKey:@"CFBundleIconFiles"]objectAtIndex:0]]]];
                                        [appNames addObject:[app localizedName]];
                                        [appBundleIDs addObject:[app applicationIdentifier]];
                                    } else if ([UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%s/%@@3x.png",[[app bundleURL] fileSystemRepresentation],[[[[infoPlist objectForKey:@"CFBundleIcons"] objectForKey:@"CFBundlePrimaryIcon"] objectForKey:@"CFBundleIconFiles"]objectAtIndex:0]]]) {
                                [appImages addObject:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%s/%@@3x.png",[[app bundleURL] fileSystemRepresentation],[[[[infoPlist objectForKey:@"CFBundleIcons"] objectForKey:@"CFBundlePrimaryIcon"] objectForKey:@"CFBundleIconFiles"]objectAtIndex:0]]]];
                                        [appNames addObject:[app localizedName]];
                                        [appBundleIDs addObject:[app applicationIdentifier]];
                                    } else {
                                        [appImages addObject:@"NOIMG"];
                                        [appNames addObject:[app localizedName]];
                                        [appBundleIDs addObject:[app applicationIdentifier]];
                                    }
                                } else {
                                    [appImages addObject:@"NOIMG"];
                                    [appNames addObject:[app localizedName]];
                                    [appBundleIDs addObject:[app applicationIdentifier]];
                                }
                        } else {
                            [appImages addObject:@"NOIMG"];
                            [appNames addObject:[app localizedName]];
                            [appBundleIDs addObject:[app applicationIdentifier]];;
                        }
                    } else {
                        [appImages addObject:@"NOIMG"];
                        [appNames addObject:[app localizedName]];
                        [appBundleIDs addObject:[app applicationIdentifier]];
                    }
                } else {
                    if ([infoPlist objectForKey:@"CFBundleIconFiles"]) {
                        [appImages addObject:[UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%s/%@.png",[[app bundleURL] fileSystemRepresentation],[[infoPlist objectForKey:@"CFBundleIconFiles"]objectAtIndex:0]]]];
                    } else {
                        [appImages addObject:@"NOIMG"];
                    }
                    [appNames addObject:[app localizedName]];
                    [appBundleIDs addObject:[app applicationIdentifier]];
                }*/
                infoPlist = nil;
            }
            
        }
    } else {
        NSLog(@"NOPE");
    }
    /*Class appInfo = NSClassFromString(@"appInfo");
    id appInfoInstance = [appInfo sharedInstance];
    [appInfoInstance addObserver:self];
    if (appInfoInstance) {
        [appInfoInstance setAppImages:appImages];
        [appInfoInstance setAppNames:appNames];
    }*/
    self.myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,self.view.frame.size.height) style:UITableViewStylePlain]; //previously self.view.frame.size.height + 35 iPod Touch 7, y value is 110 on iPod Touch 7 and 130 on iPhone 11 (UIScreen.mainScreen.applicationFrame.size.height/15.2)-(548/15.2)
    self.myTableView.dataSource = self;
    self.myTableView.delegate = self;
    if (@available(iOS 11.0, *)) {
        //self.navigationController.navigationBar.prefersLargeTitles = NO;
        [_myTableView setFrame:CGRectMake(10, 0, _myTableView.frame.size.width - 20, _myTableView.frame.size.height)];
    } else {
        [_myTableView setFrame:CGRectMake(0, 0, _myTableView.frame.size.width, _myTableView.frame.size.height)];
    }
    //_myTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.myTableView];
    //self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    if (@available(iOS 13.0, *)) {
        self.view.backgroundColor = [UIColor systemBackgroundColor];
        self.navigationController.navigationBar.backgroundColor = [UIColor systemBackgroundColor];
    } else {
        // Fallback on earlier versions
        self.view.backgroundColor = [UIColor whiteColor];
        self.navigationController.navigationBar.backgroundColor = [UIColor whiteColor];
        
    }
    UIView *topNotchCover;
    topNotchCover = [[UIView alloc]initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.applicationFrame.size.width, self.navigationController.navigationBar.frame.size.height / 1.5)]; //height 96 on 852, 91 on 548
    topNotchCover.hidden = NO;
    topNotchCover.backgroundColor = self.navigationController.navigationBar.backgroundColor;
    [self.view addSubview:topNotchCover];
    self.view.backgroundColor = self.navigationController.navigationBar.backgroundColor;
    //self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [appNames count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //NSLog(@"appNames count: %lu",(unsigned long)[appNames count]);
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    //REMEMBER! MAKE SURE YOU UPDATE VIEWCONTROLLER FOR INSTALLED USER APPS THAT DON'T HAVE ICONS!!!
    cell.textLabel.text = [appNames objectAtIndex:indexPath.row];
    if ([[appImages objectAtIndex:indexPath.row]isEqual:@"NOIMG"]){}else{
        cell.imageView.image = [appImages objectAtIndex:indexPath.row];
    }
    cell.backgroundColor = cellColorFromRow(indexPath.row);
    cell.layer.masksToBounds = YES;
    if (@available(iOS 11.0, *)) {
        if (indexPath.row == 0) {
            cell.layer.cornerRadius = 15.0;
            [cell.layer setMaskedCorners:3]; /*kCALayerMaxXMinYCorner|kCALayerMinXMinYCorner*/
        } else if (indexPath.row == [appNames count]-1) {
            cell.layer.cornerRadius = 15.0;
            [cell.layer setMaskedCorners:12]; /*kCALayerMinXMaxYCorner|kCALayerMaxXMaxYCorner*/
        } else {
            cell.layer.cornerRadius = 0.0;
            [cell.layer setMaskedCorners:0];
        }
    }
    /*if (@available(iOS 11.0, *)) {
        if (indexPath.row == (long)0) {
            NSLog(@"app at %ld: %@",(long)indexPath.row,[appNames objectAtIndex:indexPath.row]);
            cell.layer.cornerRadius = 15.0;
            [cell.layer setMaskedCorners:kCALayerMaxXMinYCorner|kCALayerMinXMinYCorner];
        } else if (indexPath.row == (long)([appNames count]-1)) {
            NSLog(@"app mat %ld: %@",(long)indexPath.row,[appNames objectAtIndex:indexPath.row]);
            cell.layer.cornerRadius = 15.0;
            [cell.layer setMaskedCorners:kCALayerMinXMaxYCorner|kCALayerMaxXMaxYCorner];
        }
    }*/
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    /*Class appInfo = NSClassFromString(@"appInfo");
    id appInfoInstance = [appInfo sharedInstance];
    //[appInfoInstance addObserver:self];
    if (appInfoInstance) {
        [appInfoInstance setAppName:[appNames objectAtIndex:indexPath.row]];
    }*/
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    BadgeCountMinimumViewController *myNewVC = (BadgeCountMinimumViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgeCountMinimumViewController"];
    myNewVC.appName = [appNames objectAtIndex:indexPath.row];
    myNewVC.cellTitle = [self cellTitle];
    myNewVC.appBundleID = [appBundleIDs objectAtIndex:indexPath.row];
    NSLog(@"appName: %@",[appNames objectAtIndex:indexPath.row]);
    NSLog(@"cellTitle: %@",[self cellTitle]);
    NSLog(@"appBundleID: %@",[appBundleIDs objectAtIndex:indexPath.row]);
    [self.navigationController pushViewController:myNewVC animated:YES];
}

@end
