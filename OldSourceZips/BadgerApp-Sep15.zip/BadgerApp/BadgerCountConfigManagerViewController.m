//
//  BadgerCountConfigManagerViewController.m
//  BadgerApp
//
//  Created by Snoolie Keffaber on 9/12/22.
//

#import "BadgerCountConfigManagerViewController.h"
#include "BadgerPrefHandler.h"
#import "BadgerCountConfigItem.h"
#import "BadgeCountMinimumViewController.h"

//NSArray *configs;
NSMutableArray *configs;
id _param;

@interface BadgerCountConfigManagerViewController () <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *configsTableView;
-(void)createCountConfig:(id)sender;
@end

@implementation BadgerCountConfigManagerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _param = self;
    self.navigationItem.title = @"Configs";
    [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc]initWithTitle:@"+" style:UIBarButtonItemStylePlain target:self action:@selector(createCountConfig:)]];
    configs = [[NSMutableArray alloc]initWithObjects:@"Default", nil];
    if ([[self cellTitle]isEqualToString:@"Badge Image"]) {
        [configs addObjectsFromArray:badgerRetriveConfigsWithUniversalPref(@"BadgeImagePath")];
    } else if ([[self cellTitle]isEqualToString:@"Custom Badge Label"]) {
        [configs addObjectsFromArray:badgerRetriveConfigsWithUniversalPref(@"BadgeLabel")];
    }
    //configs = [[NSArray alloc]initWithArray:mutableConfigs];
    self.configsTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,self.view.frame.size.height) style:UITableViewStylePlain];
    self.configsTableView.dataSource = self;
    self.configsTableView.delegate = self;
    if (@available(iOS 11.0, *)) {
        [_configsTableView setFrame:CGRectMake(0, 0, _configsTableView.frame.size.width, _configsTableView.frame.size.height)];
    } else {
        [_configsTableView setFrame:CGRectMake(0, 0, _configsTableView.frame.size.width, _configsTableView.frame.size.height)];
    }
    [self.view addSubview:self.configsTableView];
    if (@available(iOS 13.0, *)) {
        self.view.backgroundColor = [UIColor systemBackgroundColor];
        self.navigationController.navigationBar.backgroundColor = [UIColor systemBackgroundColor];
    } else {
        // Fallback on earlier versions
        self.view.backgroundColor = [UIColor whiteColor];
        self.navigationController.navigationBar.backgroundColor = [UIColor whiteColor];
        
    }
    UIView *topNotchCover;
    topNotchCover = [[UIView alloc]initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.applicationFrame.size.width, self.navigationController.navigationBar.frame.size.height / 1.5)];
    topNotchCover.hidden = NO;
    topNotchCover.backgroundColor = self.navigationController.navigationBar.backgroundColor;
    [self.view addSubview:topNotchCover];
    self.view.backgroundColor = self.navigationController.navigationBar.backgroundColor;
    // Do any additional setup after loading the view.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [configs count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BadgerCountConfigItem *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[BadgerCountConfigItem alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = [configs objectAtIndex:indexPath.row];
    if (indexPath.row != 0) {
    UIButton *deleteButton = [[UIButton alloc]initWithFrame:CGRectMake(UIScreen.mainScreen.applicationFrame.size.width / 2, 0, UIScreen.mainScreen.applicationFrame.size.width / 2 - 10, 44)];
    [deleteButton setTitle:@"Delete" forState:UIControlStateNormal];
        [deleteButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [deleteButton setTintColor:[UIColor blueColor]];
        [deleteButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [deleteButton addTarget:cell action:@selector(deleteCountConfig:) forControlEvents:UIControlEventTouchUpInside];
        [cell addSubview:deleteButton];
    } else {
        UIButton *resetButton = [[UIButton alloc]initWithFrame:CGRectMake(UIScreen.mainScreen.applicationFrame.size.width / 2, 0, UIScreen.mainScreen.applicationFrame.size.width / 2 - 10, 44)];
        [resetButton setTitle:@"Reset" forState:UIControlStateNormal];
            [resetButton setTranslatesAutoresizingMaskIntoConstraints:NO];
            [resetButton setTintColor:[UIColor blueColor]];
            [resetButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
            [resetButton addTarget:cell action:@selector(resetDefaultConfig:) forControlEvents:UIControlEventTouchUpInside];
            [cell addSubview:resetButton];
    }
    //[deleteButton addTarget:self action:@selector(deleteCountConfig:) forControlEvents:UIControlEventValueChanged];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *countConfig = [configs objectAtIndex:indexPath.row];
    if ([[self cellTitle]isEqualToString:@"Custom Badge Label"]) {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgeCountMinimumViewController *myNewVC = (BadgeCountMinimumViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgeCountMinimumViewController"];
        myNewVC.cellTitle = [self cellTitle];
        if (![countConfig isEqualToString:@"Default"]) {
            myNewVC.badgeCount = (int)[countConfig integerValue];
        }
        [self.navigationController pushViewController:myNewVC animated:YES];
    }
    //go to view controller corresponding with cellTitle, pass countConfig into it
}
-(void)createCountConfig:(id)sender {
    if (@available(iOS 8.0, *)) {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Badger"
                                                                       message:@"Input the minimum number of notifications you want your setting to appear."
                                                                preferredStyle:UIAlertControllerStyleAlert];
        [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            textField.placeholder = @"2";
        }];
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSLog(@"Count config %@", [[alert textFields][0] text]);
            [self completeCountConfig:[[alert textFields][0] text]];
        }];
        [alert addAction:confirmAction];
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        // Fallback on earlier versions
        
        //nothing atm lol
        //maybe for iOS 7- go to a new view controller with a editable TextView?
    }
}
-(void)deleteRowWithTitle:(NSString *)rowTitle {
    [configs removeObject:rowTitle];
    if ([[self cellTitle]isEqualToString:@"Custom Badge Label"]) {
        badgerRemoveUniversalCountPref((int)[rowTitle integerValue], @"BadgeLabel");
    }
    [_configsTableView reloadData];
}
-(void)resetDefault:(NSString *)rowTitle {
    if ([[self cellTitle]isEqualToString:@"Custom Badge Label"]) {
        badgerRemoveUniversalPref(@"BadgeLabel");
    }
}
-(void)completeCountConfig:(NSString *)countConfig {
    NSString *newText;
    NSScanner *scanner = [NSScanner scannerWithString:countConfig];
    NSCharacterSet *numbers = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
    [scanner scanUpToCharactersFromSet:numbers intoString:NULL];
    [scanner scanCharactersFromSet:numbers intoString:&newText];
    if (newText.length < 1) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"Invalid Count Configuration"]
                                                        message:@"Please input a number."
                                                       delegate:self
                                              cancelButtonTitle:@"Okay"
                                              otherButtonTitles:nil];
        [alert show];
    } else {
        if ([newText integerValue] < 2) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"Invalid Count Configuration"]
                                                            message:@"You need to set your badge count configuration to 2 or more. Use default instead, count configs will overrule it if you have any, and when a count config is not in use it will default to your default configuration."
                                                           delegate:self
                                                  cancelButtonTitle:@"Okay"
                                                  otherButtonTitles:nil];
            [alert show];
        } else {
            //we don't need to save count config yet, just when user makes a value
            [configs addObject:[@([newText integerValue])stringValue]];
            [self->_configsTableView reloadData];
        }
    }
}
@end

void deleteRowWithTitle(NSString *rowTitle) {
    if (![rowTitle isEqualToString:@"Default"]) {
        [_param deleteRowWithTitle:rowTitle];
    }
}

void resetDefault(NSString *rowTitle) {
    if ([rowTitle isEqualToString:@"Default"]) {
        [_param resetDefault:rowTitle];
    }
}
