//
//  BadgerCountConfigManagerViewController.m
//  BadgerApp
//
//  Created by Zachary Keffaber on 9/12/22.
//

#import "BadgerCountConfigManagerViewController.h"

@interface BadgerCountConfigManagerViewController () <UITableViewDelegate, UITableViewDataSource>

@end

@implementation BadgerCountConfigManagerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
