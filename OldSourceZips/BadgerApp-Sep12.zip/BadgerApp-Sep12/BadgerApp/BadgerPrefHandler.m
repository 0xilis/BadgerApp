//
//  BadgerPrefHandler.m
//  BadgerApp
//
//  Created by Snoolie Keffaber on 9/9/22.
//

#include "BadgerPrefHandler.h"

//NSString *preferencesDirectory = @"/var/Badger/TestBadgerPrefs.plist";
NSString *preferencesDirectory = @"/Users/zachary7829/Desktop/xCode stuff/BadgerApp/BadgerApp/TestBadgerPrefs.plist";

void badgerSaveUniversalPref(NSString *prefKey, id prefValue) {
    NSMutableDictionary *badgerPlist = [[NSMutableDictionary alloc]initWithContentsOfFile:preferencesDirectory];
    [[[badgerPlist objectForKey:@"UniversalConfiguration"]objectForKey:@"DefaultConfig"]setObject:prefValue forKey:prefKey];
    [badgerPlist writeToFile:preferencesDirectory atomically:YES];
}
//prefApp is app's bundle ID
void badgerSaveAppPref(NSString *prefApp, NSString *prefKey, id prefValue) {
    NSMutableDictionary *badgerPlist = [[NSMutableDictionary alloc]initWithContentsOfFile:preferencesDirectory];
    if (![[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]) {
        [[badgerPlist objectForKey:@"AppConfiguration"]setObject:[[NSMutableDictionary alloc]init] forKey:prefApp];
    }
    if (![[[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]objectForKey:@"DefaultConfig"]) {
        [[[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]setObject:[[NSMutableDictionary alloc]init] forKey:@"DefaultConfig"];
    }
    [[[[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]objectForKey:@"DefaultConfig"]setObject:prefValue forKey:prefKey];
    [badgerPlist writeToFile:preferencesDirectory atomically:YES];
}

void badgerSaveUniversalCountPref(int count, NSString *prefKey, id prefValue) {
    //For Custom Labels & Custom Images
}
void badgerSaveAppCountPref(int count, NSString *prefApp, NSString *prefKey, id prefValue) {
    NSLog(@"BadgerApp does currently not use this, will be finished latr.");
}

void badgerRemoveUniversalPref(NSString *prefKey) {
    NSMutableDictionary *badgerPlist = [[NSMutableDictionary alloc]initWithContentsOfFile:preferencesDirectory];
    [[[badgerPlist objectForKey:@"UniversalConfiguration"]objectForKey:@"DefaultConfig"]removeObjectForKey:prefKey];
    [badgerPlist writeToFile:preferencesDirectory atomically:YES];
}
//prefApp is app's bundle ID
void badgerRemoveAppPref(NSString *prefApp, NSString *prefKey) {
    NSMutableDictionary *badgerPlist = [[NSMutableDictionary alloc]initWithContentsOfFile:preferencesDirectory];
    if ([[[[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]objectForKey:@"DefaultConfig"]objectForKey:prefKey]) {
        if (([[[[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]objectForKey:@"DefaultConfig"]count] == 1) && (![[[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]objectForKey:@"CountSpecificConfigs"])) {
            //if the key we're removing is the only key, remove the app config altogether, speeds up the tweak a little
            [[badgerPlist objectForKey:@"AppConfiguration"]removeObjectForKey:prefApp];
        } else {
            [[[[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]objectForKey:@"DefaultConfig"]removeObjectForKey:prefKey];
        }
        [badgerPlist writeToFile:preferencesDirectory atomically:YES];
    }
}

void badgerSetUpPrefPlist(void){
    NSMutableDictionary *badgerPlist = [[NSMutableDictionary alloc]initWithObjectsAndKeys:[[NSMutableDictionary alloc]initWithObjectsAndKeys:[[NSMutableDictionary alloc]init],@"DefaultConfig", nil],@"UniversalConfiguration",[[NSMutableDictionary alloc]init],@"AppConfiguration", nil];
    [badgerPlist writeToFile:preferencesDirectory atomically:YES];
}

id badgerRetriveUniversalPref(NSString *prefKey) {
    NSMutableDictionary *badgerPlist = [[NSMutableDictionary alloc]initWithContentsOfFile:preferencesDirectory];
    if ([[[badgerPlist objectForKey:@"UniversalConfiguration"]objectForKey:@"DefaultConfig"]objectForKey:prefKey]) {
        return [[[badgerPlist objectForKey:@"UniversalConfiguration"]objectForKey:@"DefaultConfig"]objectForKey:prefKey];
    }
    return NULL;
}
//prefApp is app's bundle ID
id badgerRetriveAppPref(NSString *prefApp, NSString *prefKey) {
    NSMutableDictionary *badgerPlist = [[NSMutableDictionary alloc]initWithContentsOfFile:preferencesDirectory];
    if ([[[[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]objectForKey:@"DefaultConfig"]objectForKey:prefKey]) {
        return [[[[badgerPlist objectForKey:@"AppConfiguration"]objectForKey:prefApp]objectForKey:@"DefaultConfig"]objectForKey:prefKey];
    }
    return NULL;
}
