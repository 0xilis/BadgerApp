//
//  AppDelegate.h
//  BadgerApp
//
//  Created by Snoolie Keffaber on 8/26/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;
@end

