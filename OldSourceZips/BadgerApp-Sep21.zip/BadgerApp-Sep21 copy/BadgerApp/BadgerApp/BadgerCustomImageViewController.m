//
//  BadgerCustomImageViewController.m
//  BadgerApp
//
//  Created by Snoolie Keffaber on 9/16/22.
//

#import "BadgerCustomImageViewController.h"
#import "BadgerPrefHandler.h"

@interface BadgerCustomImageViewController () <UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *labelTitle;
@property (weak, nonatomic) IBOutlet UITextView *explainingBox;
@property (weak, nonatomic) IBOutlet UIImageView *backgd;
@property (weak, nonatomic) IBOutlet UIButton *chooseImgButton;

@end

@implementation BadgerCustomImageViewController
- (void)viewDidLoad {
    /// <UINavigationBarDelegate, UIImagePickerControllerDelegate>
    [super viewDidLoad];
    [_labelTitle setAlpha:0.5];
    [_explainingBox setAlpha:0.5];
    [_chooseImgButton setAlpha:0.5];
    [self.navigationController.navigationBar setBackgroundColor:[UIColor clearColor]];
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    [_chooseImgButton.layer setCornerRadius:5.0];
    if ([self badgeCount]) {
        if (badgerRetriveUniversalCountPref([self badgeCount], @"BadgeImagePath")) {
            [_chooseImgButton setHidden:1];
            UIImageView *badgeImage;
            if (@available(iOS 9.0, *)) {
                badgeImage = [[UIImageView alloc]initWithFrame:CGRectMake(UIScreen.mainScreen.bounds.size.width / 2 - 25, UIScreen.mainScreen.bounds.size.height / 2 - 25, 50, 50)];
            } else {
                badgeImage = [[UIImageView alloc]initWithFrame:CGRectMake(UIScreen.mainScreen.applicationFrame.size.width / 2 - 25, UIScreen.mainScreen.applicationFrame.size.height / 2 - 25, 50, 50)];
            }
            badgeImage.image = [UIImage imageWithContentsOfFile:badgerRetriveUniversalCountPref([self badgeCount], @"BadgeImagePath")];
            [self.view addSubview:badgeImage];
        }
    } else {
        if (badgerRetriveUniversalPref(@"BadgeImagePath")) {
            [_chooseImgButton setHidden:1];
            UIImageView *badgeImage;
            if (@available(iOS 9.0, *)) {
                badgeImage = [[UIImageView alloc]initWithFrame:CGRectMake(UIScreen.mainScreen.bounds.size.width / 2 - 25, UIScreen.mainScreen.bounds.size.height / 2 - 25, 50, 50)];
            } else {
                badgeImage = [[UIImageView alloc]initWithFrame:CGRectMake(UIScreen.mainScreen.applicationFrame.size.width / 2 - 25, UIScreen.mainScreen.applicationFrame.size.height / 2 - 25, 50, 50)];
            }
            badgeImage.image = [UIImage imageWithContentsOfFile:badgerRetriveUniversalPref(@"BadgeImagePath")];
            [self.view addSubview:badgeImage];
        }
    }
    // Do any additional setup after loading the view.
}

- (IBAction)pressChooseImageButton:(id)sender {
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc]init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    //imagePicker.delegate = self;
    //imagePicker.allowsEditing = YES;
    //imagePicker.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    //imagePicker.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:imagePicker animated:YES completion:nil];
    [imagePicker setDelegate:self];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info {
    UIImage *selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    [_chooseImgButton setHidden:1];
    //applicationFrame deprecated iOS 9.0+
    UIImageView *badgeImage;
    if (@available(iOS 9.0, *)) {
        badgeImage = [[UIImageView alloc]initWithFrame:CGRectMake(UIScreen.mainScreen.bounds.size.width / 2 - 25, UIScreen.mainScreen.bounds.size.height / 2 - 25, 50, 50)];
    } else {
        badgeImage = [[UIImageView alloc]initWithFrame:CGRectMake(UIScreen.mainScreen.applicationFrame.size.width / 2 - 25, UIScreen.mainScreen.applicationFrame.size.height / 2 - 25, 50, 50)];
    }
    badgeImage.image = [self imageWithImage:selectedImage scaledToSize:CGSizeMake(24,24)];
    NSData* binaryImageData = UIImagePNGRepresentation([self imageWithImage:selectedImage scaledToSize:CGSizeMake(24,24)]);
    if ([self badgeCount]) {
        [binaryImageData writeToFile:[NSString stringWithFormat:@"/var/Badger/BadgeImages/%@.png",[NSString stringWithFormat:@"%d",_badgeCount]] atomically:YES];
        badgerSaveUniversalCountPref(_badgeCount, @"BadgeImagePath", [NSString stringWithFormat:@"/var/Badger/BadgeImages/%@.png",[NSString stringWithFormat:@"%d",_badgeCount]]);
    } else {
        [binaryImageData writeToFile:@"/var/Badger/BadgeImages/Default.png" atomically:YES];
        badgerSaveUniversalPref(@"BadgeImagePath", @"/var/Badger/BadgeImages/Default.png");
    }
    
    [self.view addSubview:badgeImage];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(UIImage*)imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize {
    UIGraphicsBeginImageContext(newSize);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}
@end
