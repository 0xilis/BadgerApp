//
//  BadgerAppSelectionViewController.h
//  BadgerApp
//
//  Created by Snoolie Keffaber on 9/6/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BadgerAppSelectionViewController : UIViewController
@property (nonatomic, assign, readwrite) NSString* cellTitle;
@end

/*@interface appInfo : NSObject {
    NSString *appName;
}
+ (appInfo *)sharedInstance;
- (void)addObserver:(id)arg1;
@property (nonatomic, assign, readwrite) NSString* appName;
@end*/

NS_ASSUME_NONNULL_END
