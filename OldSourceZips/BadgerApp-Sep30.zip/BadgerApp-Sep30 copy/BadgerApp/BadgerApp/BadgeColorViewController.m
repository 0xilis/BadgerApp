//
//  BadgeColorViewController.m
//  BadgerApp
//
//  Created by Snoolie Keffaber on 9/6/22.
//

#import "ViewController.h"
#import "BadgeColorViewController.h"
#include "BadgerPrefHandler.h"

NSArray *colorsToPick;

@interface BadgeColorViewController () <UIPickerViewDataSource, UIPickerViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UITextView *explainingBox;
@property (weak, nonatomic) IBOutlet UIPickerView *colorPicker;
@property (weak, nonatomic) IBOutlet UIImageView *backgd;
@end

@implementation BadgeColorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_label setFont:[UIFont fontWithName:@"Helvetica-Bold" size:25.0f]];
    [_explainingBox setFont:[UIFont fontWithName:@"Helvetica-Bold" size:18.0f]];
    self.navigationController.navigationBar.backgroundColor = [UIColor clearColor];
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
   // _colorPicker.showsSelectionIndicator = NO;
    
    //remember to don't just set these to red, but once pref saving is implemented pull from prefs and get that color
    if ([[self cellTitle]isEqualToString:@"Badge Color"] || [[self cellTitle]isEqualToString:@"Badge Color for App"]) {
        colorsToPick = [[NSArray alloc]initWithObjects:@"Default (Red)",@"Pink",@"Orange",@"Yellow",@"Green",@"Blue",@"Purple",@"Magenta",@"Teal",@"Brown",@"Black",@"White", nil];
        NSString *badgeColor;
        if ([self appBundleID]) {
            [_backgd setImage:[UIImage imageNamed:@"RPurpleGrad.png"]];
            badgeColor = [badgerRetriveAppPref([self appBundleID],@"BadgeColor")objectForKey:@"ColorName"];
        } else {
            badgeColor = [badgerRetriveUniversalPref(@"BadgeColor")objectForKey:@"ColorName"];
        }
        if (badgeColor == nil) {
            badgeColor = @"Default (Red)";
        }
        [_explainingBox setTextColor:matchingLabelColor(badgeColor)];
        [_label setTextColor:matchingLabelColor(badgeColor)];
        [_colorPicker selectRow:[colorsToPick indexOfObject:badgeColor] inComponent:0 animated:NO];
        if ([self appBundleID]) {
            [_explainingBox setText:[NSString stringWithFormat:@"This affects the badge color for %@",[self appName]]];
        }
    } else if ([[self cellTitle]isEqualToString:@"Badge Position"]) {
        colorsToPick = [[NSArray alloc]initWithObjects:@"Default (Top Right)",@"Top Left",@"Bottom Right",@"Bottom Left",@"Center", nil];
        if ([badgerRetriveUniversalPref(@"BadgePosition")objectForKey:@"PositionName"]) {
        [_colorPicker selectRow:[colorsToPick indexOfObject:[badgerRetriveUniversalPref(@"BadgePosition")objectForKey:@"PositionName"]] inComponent:0 animated:NO];
        }
        [_label setText:@"Badge Position"];
        if ([self appBundleID]) {
            [_explainingBox setText:[NSString stringWithFormat:@"This affects the badge position for %@",[self appName]]];
        } else {
            [_explainingBox setText:@"This affects the badge position for notification badges."];
        }
        [_backgd setImage:[UIImage imageNamed:@"RYellowGrad.png"]];
        [_label setAlpha:0.5];
        [_explainingBox setAlpha:0.5];
        [_colorPicker setAlpha:0.5];
    } else if ([[self cellTitle]isEqualToString:@"Badge Shape"] || [[self cellTitle]isEqualToString:@"Badge Shape for App"]) {
        colorsToPick = [[NSArray alloc]initWithObjects:@"Default",@"Triangle",@"Square",@"Round Square",@"Hexagon", nil];
        if ([self appBundleID]) {
            if (badgerRetriveAppPref([self appBundleID], @"BadgeShape")) {
                [_colorPicker selectRow:[colorsToPick indexOfObject:badgerRetriveAppPref([self appBundleID], @"BadgeShape")] inComponent:0 animated:NO];
            }
        } else {
            if (badgerRetriveUniversalPref(@"BadgeShape")) {
                [_colorPicker selectRow:[colorsToPick indexOfObject:badgerRetriveUniversalPref(@"BadgeShape")] inComponent:0 animated:NO];
            }
        }
            [_label setText:@"Badge Shape"];
        if ([self appBundleID]) {
            [_explainingBox setText:[NSString stringWithFormat:@"This affects the shape for %@",[self appName]]];
            [_backgd setImage:[UIImage imageNamed:@"RBlueGrad.png"]];
        } else {
            [_explainingBox setText:@"This affects the shape for notification badges."];
            [_backgd setImage:[UIImage imageNamed:@"RGreenGrad.png"]];
        }
        [_label setAlpha:0.5];
        [_explainingBox setAlpha:0.5];
        [_colorPicker setAlpha:0.5];
    } else if ([[self cellTitle]isEqualToString:@"Badge Label Color"] || [[self cellTitle]isEqualToString:@"Badge Label Color for App"]) {
        [_label setText:@"Badge Label Color"];
        colorsToPick = [[NSArray alloc]initWithObjects:@"Default (White)",@"Red",@"Pink",@"Orange",@"Yellow",@"Green",@"Blue",@"Purple",@"Magenta",@"Teal",@"Brown",@"Black", nil];
        NSString *badgeColor;
        if ([self appBundleID]) {
            [_backgd setImage:[UIImage imageNamed:@"RPurpleGrad.png"]];
            if ([self badgeCount]) {
                badgeColor = [badgerRetriveAppCountPref([self badgeCount],[self appBundleID],@"BadgeLabelColor")objectForKey:@"ColorName"];
            } else {
                badgeColor = [badgerRetriveAppPref([self appBundleID],@"BadgeLabelColor")objectForKey:@"ColorName"];
            }
        } else {
            [_backgd setImage:[UIImage imageNamed:@"RBlueGrad.png"]];
            if ([self badgeCount]) {
                badgeColor = [badgerRetriveUniversalCountPref([self badgeCount],@"BadgeLabelColor")objectForKey:@"ColorName"];
            } else {
                badgeColor = [badgerRetriveUniversalPref(@"BadgeLabelColor")objectForKey:@"ColorName"];
            }
        }
        if (badgeColor == nil) {
            badgeColor = @"Default (White)";
        }
        [_explainingBox setTextColor:matchingLabelColor(badgeColor)];
        [_label setTextColor:matchingLabelColor(badgeColor)];
        [_colorPicker selectRow:[colorsToPick indexOfObject:badgeColor] inComponent:0 animated:NO];
        if ([self appBundleID]) {
            [_explainingBox setText:[NSString stringWithFormat:@"This affects the label color for %@",[self appName]]];
        }
    }
    
    // Do any additional setup after loading the view.
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [colorsToPick objectAtIndex:row];
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [colorsToPick count];
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *label = (id)view;

        if (!label)
        {

            label= [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [pickerView rowSizeForComponent:component].width, [pickerView rowSizeForComponent:component].height)];
            label.textAlignment = NSTextAlignmentCenter;
            if ([[self cellTitle]isEqualToString:@"Badge Color"] || [[self cellTitle]isEqualToString:@"Badge Color for App"] || [[self cellTitle]isEqualToString:@"Badge Label Color"] || [[self cellTitle]isEqualToString:@"Badge Label Color for App"]) {
            label.textColor = matchingLabelColor([colorsToPick objectAtIndex:row]);
            }
            label.font = [UIFont fontWithName:@"Helvetica-Bold" size:14.0f];
            label.text = [colorsToPick objectAtIndex:row];
            label.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.3];

        }

        return label;
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if ([[self cellTitle]isEqualToString:@"Badge Color"] || [[self cellTitle]isEqualToString:@"Badge Color for App"]) {
    [_explainingBox setTextColor:matchingLabelColor([colorsToPick objectAtIndex:row])];
    [_label setTextColor:matchingLabelColor([colorsToPick objectAtIndex:row])];
    if ([[colorsToPick objectAtIndex:row]isEqualToString:@"Default (Red)"]) {
        //remove BadgeColor since we're default anyway
        if ([self appBundleID]) {
            badgerRemoveAppPref([self appBundleID], @"BadgeColor");
        } else {
            badgerRemoveUniversalPref(@"BadgeColor");
        }
    } else {
        CGFloat red, green, blue, alpha;
        [matchingLabelColor([colorsToPick objectAtIndex:row]) getRed:&red green: &green blue: &blue alpha: &alpha];
        if ([self appBundleID]) {
            badgerSaveAppPref([self appBundleID], @"BadgeColor", [[NSDictionary alloc]initWithObjectsAndKeys:[NSString stringWithFormat:@"%f",blue],@"Blue",[NSString stringWithFormat:@"%f",green],@"Green",[NSString stringWithFormat:@"%f",red],@"Red",[colorsToPick objectAtIndex:row],@"ColorName", nil]);
        } else {
            badgerSaveUniversalPref(@"BadgeColor", [[NSDictionary alloc]initWithObjectsAndKeys:[NSString stringWithFormat:@"%f",blue],@"Blue",[NSString stringWithFormat:@"%f",green],@"Green",[NSString stringWithFormat:@"%f",red],@"Red",[colorsToPick objectAtIndex:row],@"ColorName", nil]);
        }
    }
    } else if ([[self cellTitle]isEqualToString:@"Badge Label Color"] || [[self cellTitle]isEqualToString:@"Badge Label Color for App"]) {
        [_explainingBox setTextColor:matchingLabelColor([colorsToPick objectAtIndex:row])];
        [_label setTextColor:matchingLabelColor([colorsToPick objectAtIndex:row])];
        if ([[colorsToPick objectAtIndex:row]isEqualToString:@"Default (White)"]) {
            //remove BadgeColor since we're default anyway
            if ([self appBundleID]) {
                if ([self badgeCount]) {
                    badgerRemoveAppCountPref([self badgeCount],[self appBundleID], @"BadgeLabelColor");
                } else {
                    badgerRemoveAppPref([self appBundleID], @"BadgeLabelColor");
                }
            } else {
                if ([self badgeCount]) {
                    badgerRemoveUniversalCountPref([self badgeCount],@"BadgeLabelColor");
                } else {
                    badgerRemoveUniversalPref(@"BadgeLabelColor");
                }
            }
        } else {
            CGFloat red, green, blue, alpha;
            [matchingLabelColor([colorsToPick objectAtIndex:row]) getRed:&red green: &green blue: &blue alpha: &alpha];
            if ([self appBundleID]) {
                if ([self badgeCount]) {
                    badgerSaveAppCountPref([self badgeCount],[self appBundleID], @"BadgeLabelColor", [[NSDictionary alloc]initWithObjectsAndKeys:[NSString stringWithFormat:@"%f",blue],@"Blue",[NSString stringWithFormat:@"%f",green],@"Green",[NSString stringWithFormat:@"%f",red],@"Red",[colorsToPick objectAtIndex:row],@"ColorName", nil]);
                } else {
                    badgerSaveAppPref([self appBundleID], @"BadgeLabelColor", [[NSDictionary alloc]initWithObjectsAndKeys:[NSString stringWithFormat:@"%f",blue],@"Blue",[NSString stringWithFormat:@"%f",green],@"Green",[NSString stringWithFormat:@"%f",red],@"Red",[colorsToPick objectAtIndex:row],@"ColorName", nil]);
                }
            } else {
                if ([self badgeCount]) {
                    badgerSaveUniversalCountPref([self badgeCount],@"BadgeLabelColor", [[NSDictionary alloc]initWithObjectsAndKeys:[NSString stringWithFormat:@"%f",blue],@"Blue",[NSString stringWithFormat:@"%f",green],@"Green",[NSString stringWithFormat:@"%f",red],@"Red",[colorsToPick objectAtIndex:row],@"ColorName", nil]);
                } else {
                    badgerSaveUniversalPref(@"BadgeLabelColor", [[NSDictionary alloc]initWithObjectsAndKeys:[NSString stringWithFormat:@"%f",blue],@"Blue",[NSString stringWithFormat:@"%f",green],@"Green",[NSString stringWithFormat:@"%f",red],@"Red",[colorsToPick objectAtIndex:row],@"ColorName", nil]);
                }
            }
        }
    } else if ([[self cellTitle]isEqualToString:@"Badge Position"]) {
        //Badge Position
        if ([[colorsToPick objectAtIndex:row]isEqualToString:@"Default (Top Right)"]) {
            //remove BadgeColor since we're default anyway
            badgerRemoveUniversalPref(@"BadgePosition");
        } else {
            if ([[colorsToPick objectAtIndex:row]isEqualToString:@"Top Left"]) {
                badgerSaveUniversalPref(@"BadgePosition", [[NSDictionary alloc]initWithObjectsAndKeys:@54,@"CenterXOffset",@0,@"CenterYOffset",[colorsToPick objectAtIndex:row],@"PositionName", nil]);
            } else if ([[colorsToPick objectAtIndex:row]isEqualToString:@"Bottom Right"]) {
                badgerSaveUniversalPref(@"BadgePosition", [[NSDictionary alloc]initWithObjectsAndKeys:@0,@"CenterXOffset",@54,@"CenterYOffset",[colorsToPick objectAtIndex:row],@"PositionName", nil]);
            } else if ([[colorsToPick objectAtIndex:row]isEqualToString:@"Bottom Left"]) {
                badgerSaveUniversalPref(@"BadgePosition", [[NSDictionary alloc]initWithObjectsAndKeys:@54,@"CenterXOffset",@54,@"CenterYOffset",[colorsToPick objectAtIndex:row],@"PositionName", nil]);
            } else if ([[colorsToPick objectAtIndex:row]isEqualToString:@"Center"]) {
                badgerSaveUniversalPref(@"BadgePosition", [[NSDictionary alloc]initWithObjectsAndKeys:@27,@"CenterXOffset",@27,@"CenterYOffset",[colorsToPick objectAtIndex:row],@"PositionName", nil]);
            }
        }
    } else {
        if ([[colorsToPick objectAtIndex:row]isEqualToString:@"Default"]) {
            //remove BadgeColor since we're default anyway
            if ([self appBundleID]) {
                badgerRemoveAppPref([self appBundleID], @"BadgeShape");
            } else {
                badgerRemoveUniversalPref(@"BadgeShape");
            }
        } else {
            if ([self appBundleID]) {
                badgerSaveAppPref([self appBundleID], @"BadgeShape", [colorsToPick objectAtIndex:row]);
            } else {
                badgerSaveUniversalPref(@"BadgeShape",[colorsToPick objectAtIndex:row]);
            }
        }
    }
}
@end

UIColor *matchingLabelColor(NSString *color) {
    if ([color isEqualToString:@"Default (Red)"]) {
        return [UIColor redColor];
    } else if ([color isEqualToString:@"Pink"]) {
        return [UIColor systemPinkColor];
    } else if ([color isEqualToString:@"Orange"]) {
        return [UIColor orangeColor];
    } else if ([color isEqualToString:@"Yellow"]) {
        return [UIColor yellowColor];
    } else if ([color isEqualToString:@"Green"]) {
        return [UIColor greenColor];
    } else if ([color isEqualToString:@"Blue"]) {
        return [UIColor blueColor];
    } else if ([color isEqualToString:@"Purple"]) {
        return [UIColor purpleColor];
    } else if ([color isEqualToString:@"Magenta"]) {
        return [UIColor magentaColor];
    } else if ([color isEqualToString:@"Teal"]) {
        return [UIColor systemTealColor];
    } else if ([color isEqualToString:@"Brown"]) {
        return [UIColor brownColor];
    } else if ([color isEqualToString:@"White"]) {
        return [UIColor whiteColor];
    } else if ([color isEqualToString:@"Default (White)"]) {
        return [UIColor whiteColor];
    } else if ([color isEqualToString:@"Red"]) {
        return [UIColor redColor];
    } else {
        return [UIColor blackColor];
    }
}
