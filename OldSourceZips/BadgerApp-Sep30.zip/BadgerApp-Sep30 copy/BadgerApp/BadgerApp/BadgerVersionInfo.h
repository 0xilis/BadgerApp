//
//  BadgerVersionInfo.h
//  BadgerApp
//
//  Created by Snoolie Keffaber on 9/27/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BadgerVersionInfo : NSObject
@property (nonatomic, assign, readwrite) BOOL isBeta;
@property (nonatomic, assign, readwrite) BOOL isExpired;
@property (nonatomic, assign, readwrite) BOOL buildCanExpire;
@property (nonatomic, assign, readwrite) char* versionExpireDate;
@property (nonatomic, assign, readwrite) long daysSinceExpire;
@property (nonatomic, assign, readwrite) NSString* badgerBuild;
@property (nonatomic, assign, readwrite) NSString* badgerVersion;
-(void)checkIsExpired;
-(void)populateSelfWithInfo;
@end

NS_ASSUME_NONNULL_END
