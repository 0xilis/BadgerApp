//
//  BadgerVersionInfo.m
//  BadgerApp
//
//  Created by Snoolie Keffaber on 9/27/22.
//

#import "BadgerVersionInfo.h"
#include <time.h>

@implementation BadgerVersionInfo

-(void)checkIsExpired {
    if ([self buildCanExpire]) {
        time_t mytime;
        struct tm * timeinfo;
        time(&mytime);
        timeinfo = localtime(&mytime);
        const char *time_str = [[NSString stringWithFormat:@"%02d%02d%02d",timeinfo->tm_year+1900,timeinfo->tm_mon+1,timeinfo->tm_mday]UTF8String];
        
        struct tm dt = {0};
        time_t dt1 = 0, dt2 = 0;
        strptime([self versionExpireDate], "%Y%m%d", &dt);
        dt2 = mktime(&dt);
        
        strptime(time_str, "%Y%m%d", &dt);
        dt1 = mktime(&dt);
        
        double seconds = difftime(dt2,dt1);
        
        long days = (seconds/(60*60*24));
        
        if (seconds < 0) {
            [self setDaysSinceExpire:days];
            [self setIsExpired:YES];
        } else {
            [self setIsExpired:NO];
        }
    } else {
        [self setIsExpired:NO];
    }
}

-(void)populateSelfWithInfo {
    [self setIsBeta:NO];
    [self setBadgerBuild:@"1A"];
    [self setBadgerVersion:@"1.0"];
    [self setBuildCanExpire:NO];
    [self setVersionExpireDate:"20231212"];
    [self setDaysSinceExpire:0];
}

@end
