//
//  ViewController.h
//  BadgerApp
//
//  Created by Snoolie Keffaber on 8/26/22.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
NSString *cellTitleFromRow(long row);
UIImage *cellImageFromRow(long row);
UIColor *cellColorFromRow(long row);
int cellRowFromTitle(NSString *cellTitle);
@end

@interface cellInfo : NSObject {
    NSString *cellTitle;
}
+ (cellInfo *)sharedInstance;
- (void)addObserver:(id)arg1;

@end
