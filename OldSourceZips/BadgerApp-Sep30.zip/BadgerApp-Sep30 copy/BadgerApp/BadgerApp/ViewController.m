//
//  ViewController.m
//  BadgerApp
//
//  Created by Snoolie Keffaber on 8/26/22.
//

#import "ViewController.h"
#import "BadgeCountMinimumViewController.h"
#import "BadgerAppSelectionViewController.h"
#import "BadgeColorViewController.h"
/*#import <sys/stat.h>
#import <sys/types.h>
#import <unistd.h>
#include <dlfcn.h>
#import <spawn.h>*/
#import "BadgerCountConfigManagerViewController.h"
#import "BadgerPrefHandler.h"
#import "BadgerVersionInfo.h"

#define ROWS 18

/*void patch_setuid(void) {
    void* handle = dlopen("/usr/lib/libjailbreak.dylib", RTLD_LAZY);
    if (!handle)
        return;

    // Reset errors
    dlerror();
    typedef void (*fix_setuid_prt_t)(pid_t pid);
    fix_setuid_prt_t ptr = (fix_setuid_prt_t)dlsym(handle, "jb_oneshot_fix_setuid_now");
    
    const char *dlsym_error = dlerror();
    if (dlsym_error)
        return;

    ptr(getpid());
}*/

@interface ViewController () <UITableViewDelegate, UITableViewDataSource>

@property (strong, nonatomic) IBOutlet UITableView *myTableView;
@end

@implementation ViewController

-(BOOL)shouldAutorotate {
    return NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*BadgerVersionInfo *versionInfo = [[BadgerVersionInfo alloc]init];
    [versionInfo populateSelfWithInfo];
    [versionInfo checkIsExpired];
    if ([versionInfo isExpired]) {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Badger Beta Build Expired"
                                                                       message:[NSString stringWithFormat:@"Beta %@ (%@) has expired. Please install the latest non-beta build from Chariz, or ask for a new beta.",[versionInfo badgerVersion],[versionInfo badgerBuild]]
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            exit(7829);
        }];
        [alert addAction:confirmAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
    //protect against BadgerVersionInfo isExpired hooking
    [versionInfo setIsExpired:YES];
    if (![versionInfo isExpired]) {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Badger Beta Build Expired"
                                                                       message:[NSString stringWithFormat:@"Beta %@ (%@) has expired. Please install the latest non-beta build from Chariz, or ask for a new beta.",[versionInfo badgerVersion],[versionInfo badgerBuild]]
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            exit(7829);
        }];
        [alert addAction:confirmAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
    //protect against BadgerVersionInfo buildCanExpire hooking
    [versionInfo setBuildCanExpire:YES];
    if (![versionInfo buildCanExpire]) {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Badger Beta Build Expired"
                                                                       message:[NSString stringWithFormat:@"Beta %@ (%@) has expired. Please install the latest non-beta build from Chariz, or ask for a new beta.",[versionInfo badgerVersion],[versionInfo badgerBuild]]
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            exit(7829);
        }];
        [alert addAction:confirmAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
    //protect against BadgerVersionInfo versionExpireDate hooking, using random number so a tweak can't just check if version expire date equals something
    srand(time(NULL));
    int minRange = 20210101;
    long maxRange = [[NSString stringWithUTF8String:[versionInfo versionExpireDate]]integerValue] - 1;
    int randvalue = rand()%((maxRange+1)-minRange) + minRange;
    [versionInfo setVersionExpireDate:((char *)[[NSString stringWithFormat:@"%d",randvalue]UTF8String])];
    if (![[NSString stringWithUTF8String:[versionInfo versionExpireDate]]isEqualToString:[NSString stringWithFormat:@"%d",randvalue]]) {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Badger Beta Build Expired"
                                                                       message:[NSString stringWithFormat:@"Beta %@ (%@) has expired. Please install the latest non-beta build from Chariz, or ask for a new beta.",[versionInfo badgerVersion],[versionInfo badgerBuild]]
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            exit(7829);
        }];
        [alert addAction:confirmAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
    //protect against BadgerVersionInfo checkIsExpired hooking, using our rand VED to prevent checking if specific VED and if so NO, else YES. ~~Also check if our values are the same as before we sent them to prevent from simply setting versionInfo values in checkIsExpired~~ prob not needed
    [versionInfo setVersionExpireDate:((char *)[[NSString stringWithFormat:@"%d",randvalue]UTF8String])];
    [versionInfo setBuildCanExpire:YES];
    [versionInfo checkIsExpired];
    if (![versionInfo isExpired]) {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Badger Beta Build Expired"
                                                                       message:[NSString stringWithFormat:@"Beta %@ (%@) has expired. Please install the latest non-beta build from Chariz, or ask for a new beta.",[versionInfo badgerVersion],[versionInfo badgerBuild]]
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            exit(7829);
        }];
        [alert addAction:confirmAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
    if (![versionInfo buildCanExpire]) {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Badger Beta Build Expired"
                                                                       message:[NSString stringWithFormat:@"Beta %@ (%@) has expired. Please install the latest non-beta build from Chariz, or ask for a new beta.",[versionInfo badgerVersion],[versionInfo badgerBuild]]
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            exit(7829);
        }];
        [alert addAction:confirmAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
    if (![[NSString stringWithUTF8String:[versionInfo versionExpireDate]]isEqualToString:[NSString stringWithFormat:@"%d",randvalue]]) {
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Badger Beta Build Expired"
                                                                       message:[NSString stringWithFormat:@"Beta %@ (%@) has expired. Please install the latest non-beta build from Chariz, or ask for a new beta.",[versionInfo badgerVersion],[versionInfo badgerBuild]]
                                                                preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            exit(7829);
        }];
        [alert addAction:confirmAction];
        [self presentViewController:alert animated:YES completion:nil];
    }*/
    /*FILE *file;
    
    if ((file = fopen("/var/mobile/Library/Badger/Prefs/BadgerPrefs.plist","r"))) {
        fclose(file);
    } else {
        badgerSetUpPrefPlist();
    }*/
    /*setuid(0);
    setuid(0);
    setgid(0);
    setgid(0);
    if(getuid() == 0) {
        NSLog(@"uid 0!");
    } else {
        if (fopen("/usr/lib/libjailbreak.dylib", "r")) {
            NSLog(@"patching setuid via libjailbreak...");
            patch_setuid();
            setuid(0);
            setuid(0);
            if (getuid() != 0) {
                NSLog(@"still not uid 0");
                NSLog(@"uid: %d",getuid());
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"Can't get uid 0"]
                                                                message:@"Badger is having troubles getting root. It may not work properly. Reach out for support. (Code 1)"
                                                               delegate:self
                                                      cancelButtonTitle:@"Okay"
                                                      otherButtonTitles:nil];
                [alert show];
            }
        } else {
            NSLog(@"not uid 0");
            NSLog(@"uid: %d",getuid());
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"Can't get uid 0"]
                                                            message:@"Badger is having troubles getting root. It may not work properly. Reach out for support. (Code 0)"
                                                           delegate:self
                                                  cancelButtonTitle:@"Okay"
                                                  otherButtonTitles:nil];
            [alert show];
        }
    }
    if(getgid() == 0) {
        NSLog(@"gid 0!");
    } else {
        NSLog(@"not gid 0");
        NSLog(@"gid: %d",getgid());
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"Can't get gid 0"]
                                                        message:@"Badger is having troubles getting root. It may not work properly. Reach out for support. (Code 2)"
                                                       delegate:self
                                              cancelButtonTitle:@"Okay"
                                              otherButtonTitles:nil];
        [alert show];
    }*/
    
    //self.navigationController.navigationBar.backgroundColor = [UIColor colorWithRed:0 green:181 blue:226 alpha:1.0];
    self.navigationController.navigationBar.userInteractionEnabled = NO;
    if (@available(iOS 13.0, *)) {
        self.navigationController.navigationBar.backgroundColor = [UIColor systemBackgroundColor];
        self.view.backgroundColor = [UIColor systemBackgroundColor];
    } else {
        // Fallback on earlier versions
        self.navigationController.navigationBar.backgroundColor = [UIColor whiteColor];
        self.view.backgroundColor = [UIColor whiteColor];
        
    }
    if (@available(iOS 11.0, *)) {
        self.navigationItem.title = @"Badger";
        self.navigationController.navigationBar.prefersLargeTitles = YES;
        //[self.navigationController.navigationBar.layer setAnchorPoint:CGPointMake(self.navigationController.navigationBar.layer.anchorPoint.x, self.navigationController.navigationBar.layer.anchorPoint.y + 0.22f)]; //+ 0.22f iPod Touch 7
    } else {
        // Fallback on earlier versions
        UILabel *newTitle = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 320, 40)];
        newTitle.text = @"Badger";
        newTitle.font = [UIFont fontWithName:@"Helvetica-Bold" size:25.0f];
        if (@available(iOS 6.0, *)) {
            newTitle.textAlignment = NSTextAlignmentLeft;
        } else {
            newTitle.textAlignment = UITextAlignmentLeft;
        }
        self.navigationItem.titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.navigationController.navigationBar.frame.size.width*3, self.navigationController.navigationBar.frame.size.height)];
        [self.navigationItem.titleView addSubview:newTitle];
        //As much as I wanted to emulate the prefersLargeTitles navbar on iOS 10, it's just way to buggy for me to implement it in the current state :(.
        //[self.navigationController.navigationBar.layer setAnchorPoint:CGPointMake(self.navigationController.navigationBar.layer.anchorPoint.x, self.navigationController.navigationBar.layer.anchorPoint.y - 1.0f)];
    }
    if (@available(iOS 11.0, *)) {
        self.myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,self.view.frame.size.height) style:UITableViewStylePlain]; //previously self.view.frame.size.height + 35 iPod Touch 7, y value is 110 on iPod Touch 7 and 130 on iPhone 11 (UIScreen.mainScreen.applicationFrame.size.height/15.2)-(548/15.2)
    } else {
        //move tableview below navbar
        self.myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0+self.navigationController.navigationBar.frame.size.height+25, self.view.frame.size.width,self.view.frame.size.height) style:UITableViewStylePlain]; //previously self.view.frame.size.height + 35 iPod Touch 7, y value is 110 on iPod Touch 7 and 130 on iPhone 11 (UIScreen.mainScreen.applicationFrame.size.height/15.2)-(548/15.2)
    }
    self.myTableView.dataSource = self;
    self.myTableView.delegate = self;
    if (@available(iOS 11.0, *)) {
        //[_myTableView setFrame:CGRectMake(10, 0, _myTableView.frame.size.width - 20, _myTableView.frame.size.height)];
    }
    //_myTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [_myTableView setShowsVerticalScrollIndicator:NO];
    [_myTableView setShowsHorizontalScrollIndicator:NO];
    [self.view addSubview:self.myTableView];
    
    //for ios 11+, since navigation bar may be below status bar, creating some funky looks with the table view
    UIView *topNotchCover;
    if (@available(iOS 11.0, *)) {
        topNotchCover = [[UIView alloc]initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.applicationFrame.size.width, self.navigationController.navigationBar.frame.size.height)]; //height 96 on 852, 91 on 548
    //
    } else {
        //topNotchCover = [[UIView alloc]initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.applicationFrame.size.width, 91+(UIScreen.mainScreen.applicationFrame.size.height/60.8)-9.01315789)]; //height 96 on 852, 91 on 548
        //As much as I wanted to emulate the prefersLargeTitles navbar on iOS 10, it's just way to buggy for me to implement it in the current state :(.
        topNotchCover = [[UIView alloc]initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.applicationFrame.size.width, self.navigationController.navigationBar.frame.size.height)];
    }
    topNotchCover.hidden = NO;
    topNotchCover.backgroundColor = self.navigationController.navigationBar.backgroundColor;
    [self.view addSubview:topNotchCover];
    //self.view.backgroundColor = [UIColor colorWithRed:173 green:216 blue:230 alpha:1.0];
    // Do any additional setup after loading the view.
}

- (void)viewDidAppear:(BOOL)animated {
    if (@available(iOS 13.0, *)) {
        self.navigationController.navigationBar.backgroundColor = [UIColor systemBackgroundColor];
        self.view.backgroundColor = [UIColor systemBackgroundColor];
    } else {
        // Fallback on earlier versions
        self.navigationController.navigationBar.backgroundColor = [UIColor whiteColor];
        self.view.backgroundColor = [UIColor whiteColor];
        
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (@available(iOS 11.0, *)) {
        //return ROWS+1;
        return ROWS;
    } else {
        return ROWS;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    /*int colorId = indexPath.row % 6;
    CGFloat red, green, blue, alpha;
    UIColor* cellColor;
    switch(colorId) {
        case 0:
            cellColor = [UIColor redColor];
            break;
        case 1:
            cellColor = [UIColor orangeColor];
            break;
        case 2:
            cellColor = [UIColor yellowColor];
            break;
        case 3:
            cellColor = [UIColor greenColor];
            break;
        case 4:
            cellColor = [UIColor blueColor];
            break;
        case 5:
            cellColor = [UIColor purpleColor];
            break;
        default:
            NSLog(@"Badger Error: No color set for cell colorId %d\n",colorId);
            cellColor = cell.backgroundColor;
            break;
    }
    [cellColor getRed:&red green: &green blue: &blue alpha: &alpha]; //iOS 5.0+
    cell.backgroundColor = [UIColor colorWithRed:red green:green blue:blue alpha:0.5];*/
    //cell.backgroundColor = cellColorFromRow(indexPath.row);
    cell.textLabel.text = cellTitleFromRow(indexPath.row);
    cell.imageView.image = cellImageFromRow(indexPath.row);
    //cell.layer.cornerRadius = 15.0;
    [cell.textLabel setAdjustsFontSizeToFitWidth:1];
    if (indexPath.row > (ROWS-1)) {
        [cell setHidden:1];
    }
    /*if (@available(iOS 11.0, *)) {
        if (indexPath.row == 0) {
            cell.layer.cornerRadius = 15.0;
            [cell.layer setMaskedCorners:kCALayerMaxXMinYCorner|kCALayerMinXMinYCorner];
        } else if (indexPath.row == ROWS-1) {
            cell.layer.cornerRadius = 15.0;
            [cell.layer setMaskedCorners:kCALayerMinXMaxYCorner|kCALayerMaxXMaxYCorner];
        } else {
            cell.layer.cornerRadius = 0.0;
            [cell.layer setMaskedCorners:0];
        }
    }*/
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *cellTitle = cellTitleFromRow(indexPath.row);
    Class cellInfo = NSClassFromString(@"cellInfo");
    id cellInfoInstance = [cellInfo sharedInstance];
    [cellInfoInstance addObserver:self];
    if (cellInfoInstance) {
        [cellInfoInstance setCellTitle:cellTitle];
    }
    if ([cellTitle isEqualToString:@"Badge Count Minimum"]) {
        NSLog(@"Badge Count Minimum Pressed!");
        
        /*Class cellInfo = NSClassFromString(@"cellInfo");
        id cellInfoInstance = [cellInfo sharedInstance];
        //[cellInfoInstance addObserver:self];
        if (cellInfoInstance) {
            [cellInfoInstance setCellTitle:@"Badge Count Minimum"];
        }*/
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgeCountMinimumViewController *myNewVC = (BadgeCountMinimumViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgeCountMinimumViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Count Minimum for App"]) {
        NSLog(@"Badge Count Minimum for App Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerAppSelectionViewController *myNewVC = (BadgerAppSelectionViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerAppSelectionViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Count Limit"]) {
        NSLog(@"Badge Count Limit Pressed!");
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgeCountMinimumViewController *myNewVC = (BadgeCountMinimumViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgeCountMinimumViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Count Limit for App"]) {
        NSLog(@"Badge Count Limit for App Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerAppSelectionViewController *myNewVC = (BadgerAppSelectionViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerAppSelectionViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Color"]) {
        NSLog(@"Badge Color Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerCountConfigManagerViewController *myNewVC = (BadgerCountConfigManagerViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerCountConfigManagerViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Opacity"]) {
        NSLog(@"Badge Opacity Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerCountConfigManagerViewController *myNewVC = (BadgerCountConfigManagerViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerCountConfigManagerViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Position"]) {
        NSLog(@"Badge Position Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgeColorViewController *myNewVC = (BadgeColorViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgeColorViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Shape"]) {
        NSLog(@"Badge Shape Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerCountConfigManagerViewController *myNewVC = (BadgerCountConfigManagerViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerCountConfigManagerViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Image"]) {
        NSLog(@"Badge Image Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerCountConfigManagerViewController *myNewVC = (BadgerCountConfigManagerViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerCountConfigManagerViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Custom Badge Label"]) {
        NSLog(@"Custom Badge Label Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerCountConfigManagerViewController *myNewVC = (BadgerCountConfigManagerViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerCountConfigManagerViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Color for App"]) {
        NSLog(@"Badge Color for App Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerAppSelectionViewController *myNewVC = (BadgerAppSelectionViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerAppSelectionViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Opacity for App"]) {
        NSLog(@"Badge Opacity for App Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerAppSelectionViewController *myNewVC = (BadgerAppSelectionViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerAppSelectionViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Shape for App"]) {
        NSLog(@"Badge Shape for App Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerAppSelectionViewController *myNewVC = (BadgerAppSelectionViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerAppSelectionViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
         
    } else if ([cellTitle isEqualToString:@"Badge Size"]) {
        NSLog(@"Badge Size Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerCountConfigManagerViewController *myNewVC = (BadgerCountConfigManagerViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerCountConfigManagerViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
    } else if ([cellTitle isEqualToString:@"Badge Size for App"]) {
        NSLog(@"Badge Size for App Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerAppSelectionViewController *myNewVC = (BadgerAppSelectionViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerAppSelectionViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
    } else if ([cellTitle isEqualToString:@"Badge Label Color"]) {
        NSLog(@"Badge Label Color Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerCountConfigManagerViewController *myNewVC = (BadgerCountConfigManagerViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerCountConfigManagerViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
    } else if ([cellTitle isEqualToString:@"Badge Label Color for App"]) {
        NSLog(@"Badge Label Color for App Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerAppSelectionViewController *myNewVC = (BadgerAppSelectionViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerAppSelectionViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
    } else if ([cellTitle isEqualToString:@"Badge Image for App"]) {
        NSLog(@"Badge Image for App Pressed!");
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BadgerAppSelectionViewController *myNewVC = (BadgerAppSelectionViewController *)[storyboard instantiateViewControllerWithIdentifier:@"BadgerAppSelectionViewController"];
        myNewVC.cellTitle = cellTitle;
        [self.navigationController pushViewController:myNewVC animated:YES];
    }
}
-(NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = (UITableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    [cell setBackgroundColor:cellColorFromRow(indexPath.row)];
    return indexPath;
}
/*-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    return 66; //orig 44.0
}*/
@end
NSString *cellTitleFromRow(long row) {
    //in future *maybe*
    switch(row) {
        case 0:
            return @"Badge Count Minimum";
        case 1:
            return @"Badge Count Minimum for App";
        case 2:
            return @"Badge Count Limit";
        case 3:
            return @"Badge Count Limit for App";
        case 4:
            return @"Badge Color";
        case 5:
            return @"Badge Color for App";
        case 6:
            return @"Badge Opacity";
        case 7:
            return @"Badge Opacity for App";
        case 8:
            return @"Badge Position";
        case 9:
            return @"Badge Shape";
        case 10:
            return @"Badge Shape for App";
        case 11:
            return @"Badge Image";
        case 12:
            return @"Badge Image for App";
        case 13:
            return @"Custom Badge Label";
        case 14:
            return @"Badge Size";
        case 15:
            return @"Badge Size for App";
        case 16:
            return @"Badge Label Color";
        case 17:
            return @"Badge Label Color for App";
        case 18:
            return @"App Theme";
        default:
            NSLog(@"Badger Error: No Title Listed for Row %ld\n",row);
            return @"No Title Listed for Row";
    }
}

UIImage *cellImageFromRow(long row) {
    switch(row) {
        case 0:
            return [UIImage imageNamed:@"MinimumBadge.png"];
        case 1:
            return [UIImage imageNamed:@"MinimumBadge.png"];
        case 2:
            return [UIImage imageNamed:@"MaxBadge.png"];
        case 3:
            return [UIImage imageNamed:@"MaxBadge.png"];
        case 4:
            return [UIImage imageNamed:@"ColorBadge.png"];
        case 5:
            return [UIImage imageNamed:@"ColorBadge.png"];
        case 6:
            return [UIImage imageNamed:@"BadgeOpacity.png"];
        case 7:
            return [UIImage imageNamed:@"BadgeOpacity.png"];
        case 8:
            return [UIImage imageNamed:@"BadgePos.png"];
        case 9:
            return [UIImage imageNamed:@"BadgeShape.png"];
        case 10:
            return [UIImage imageNamed:@"BadgeShape.png"];
        case 11:
            return [UIImage imageNamed:@"ImageBadge.png"];
        case 12:
            return [UIImage imageNamed:@"ImageBadge.png"];
        case 13:
            return [UIImage imageNamed:@"CustomLabelBadge.png"];
        case 14:
            return [UIImage imageNamed:@"BadgeSize.png"];
        case 15:
            return [UIImage imageNamed:@"BadgeSize.png"];
        case 16:
            return [UIImage imageNamed:@"BadgeLabelColor.png"];
        case 17:
            return [UIImage imageNamed:@"BadgeLabelColor.png"];
        default:
            NSLog(@"Badger Error: No Image Listed for Row %ld\n",row);
            return [UIImage imageNamed:@"BadgerIcon.png"];
    }
}

NSArray *dylibPossiblePaths(void){
    return [[NSArray alloc]initWithObjects:@"/usr/lib/TweakInject/Badger.dylib",@"/var/jb/Library/TweakInject/Badger.dylib", nil];
}

UIColor *cellColorFromRow(long row) {
    int colorId = row % 6;
    CGFloat red, green, blue, alpha;
    UIColor* cellColor;
    switch(colorId) {
        case 0:
            cellColor = [UIColor redColor];
            break;
        case 1:
            cellColor = [UIColor orangeColor];
            break;
        case 2:
            cellColor = [UIColor yellowColor];
            break;
        case 3:
            cellColor = [UIColor greenColor];
            break;
        case 4:
            cellColor = [UIColor blueColor];
            break;
        case 5:
            cellColor = [UIColor purpleColor];
            break;
        default:
            NSLog(@"Badger Error: No color set for cell colorId %d\n",colorId);
            return [UIColor whiteColor];
    }
    [cellColor getRed:&red green: &green blue: &blue alpha: &alpha]; //iOS 5.0+
    return [UIColor colorWithRed:red green:green blue:blue alpha:0.5];
}

int cellRowFromTitle(NSString *cellTitle) {
    NSArray *cellTitles = [[NSArray alloc]initWithObjects:@"Badge Count Minimum",@"Badge Count Minimum for App", nil];
    int cellRow = 0;
    while ((!([[cellTitles objectAtIndex:cellRow]isEqualToString:cellTitle])) && cellRow <= cellTitles.count) {
        cellRow++;
    }
    if (cellRow > cellTitles.count) {
        return -1;
    }
    return cellRow;
}
